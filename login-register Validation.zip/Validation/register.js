
//var x = document.getElementById("mail");
function confirmpass() {
  var myInput1 = document.getElementById("ps");
  var myInput2 = document.getElementById("ps2");
  while (myInput1 != myInput2) {
    document.getElementById("ps2") = myInput;
    document.getElementById("ps2").disabled = true;
  }
}