var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

var modal2 = document.getElementById('id02');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
  if (event.target == modal2) {
    modal2.style.display = "none";
  }
}
function myfunction() {
  var x = document.getElementsByName("ps");
  //var y =document.getElementsByName("ps2");
  if (x.type === "password") {
    x.type = "text";
    //y.type ="text";
  }
  else {
    x.type = "password";

  }
}